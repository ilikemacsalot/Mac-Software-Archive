
var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, element:null, timer:null};
var backside = false;
var lastApp = null;

function createkey(key)
{
	return widget.identifier + "-" + key;
}

function loaded ()
{
	 /*   MyStoneStudio.hello()); */
}

function openApp (section)
{
    if (window.widget)
	{
	var appName = "com.stone." + section;
         MyStoneStudio.openApplication(section);
	widget.openURL("");
	// widget.openBundleId(appName);
    }
}

function clicked (section)
{
    if (window.widget)
	{
	widget.openURL('http://www.stone.com/' + section);
	}
    }





function limit_3 (a, b, c)
{
    return a < b ? b : (a > c ? c : a);
}

function computeNextFloat (from, to, ease)
{
    return from + (to - from) * ease;
}

function animate()
{
	var T;
	var ease;
	var time = (new Date).getTime();
		
	
	T = limit_3(time-animation.starttime, 0, animation.duration);
	
	if (T >= animation.duration)
	{
		clearInterval (animation.timer);
		animation.timer = null;
		animation.now = animation.to;
	}
	else
	{
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
		animation.now = computeNextFloat (animation.from, animation.to, ease);
	}
	
	animation.element.style.opacity = animation.now;
}


function mousemove (event,which)
{
	if (!flipShown)
	{
		// fade in the flip widget
		if (animation.timer != null)
		{
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		
		var starttime = (new Date).getTime() - 13; // set it back one frame
		
		animation.duration = 500;
		animation.starttime = starttime;
		animation.element = document.getElementById (which);
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 1.0;
		animate();
		flipShown = true;
	}
	
}

function mouseexit (which)
{
	if (flipShown)
	{
		// fade in the flip widget
		if (animation.timer != null)
		{
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		
		var starttime = (new Date).getTime() - 13; // set it back one frame
		
		animation.duration = 500;
		animation.starttime = starttime;
		animation.element = document.getElementById (which);
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 0.0;
		animate();
		flipShown = false;
	}
}



function showbackside(event)
{
	var front = document.getElementById("front");
	var back = document.getElementById("behind");

	if (window.widget)
		widget.prepareForTransition("ToBack");
	
	front.style.display="none";
	back.style.display="block";
	
	if (window.widget)		
		setTimeout ('widget.performTransition();', 0);	

	backside = true; 
		flipShown = false;
}

function showfrontside(event)
{
	var front = document.getElementById("front");
	var back = document.getElementById("behind");

	if (window.widget)
		widget.prepareForTransition("ToFront");
	
	front.style.display="block";
	back.style.display="none";
	
	if (window.widget)		
		setTimeout ('widget.performTransition();', 0);	

	backside = false; 
		flipShown = false;
}


function debug(msg) {
	if (!debug.box) {
		debug.box = document.createElement("div");
		debug.box.setAttribute("style", "background-color: white; " +
										"font: 14px 'Lucida Grande'; " +
"text-align:center; " +
"text-shadow: 3px 3px 3px #9933FF; " +
										"border: solid red 1px; " +
										"position: absolute; top:190px; left:220px;" +
										"padding: 4px;");
		document.body.appendChild(debug.box);
	} 
	debug.box.innerHTML = "<span style='text-align:center'>" + msg + "</span>";
	debug.box.style.display="block";
	debug2.box.style.display="none";
}
function debug2(msg) {
	if (!debug2.box) {
		debug2.box = document.createElement("div");
		debug2.box.setAttribute("style", "background-color: white; " +
										"font: 14px 'Lucida Grande'; " +
"text-align:center; " +
"text-shadow: 3px 3px 3px #9933FF; " +
										"border: solid blue 1px; " +
										"position: absolute; top:30px; left:232px; " +
										"padding: 4px;");
		document.body.appendChild(debug2.box);
	} 
	debug2.box.innerHTML = "<span style='text-align:center'>" + msg + "</span>";
	debug2.box.style.display="block";
	debug.box.style.display="none";
}

function openLastApp() {
	openApp(lastApp);
}

function feedbackcore(msg,which) {
	var orange = document.getElementById(which);
	var elem = document.getElementById(msg);
	
	orange.style.display="none";
	orange.style.left = elem.style.left;
	orange.style.top = elem.style.top;
	orange.style.display="block";
	if (msg == "TimeEqualsMoney") msg = "Time=Money";
	if (msg == "PreferenceCommander") msg = "PrefCommander";
        if (which == "orange")
	debug("Run " + msg);
        if (which == "orange2")
	debug2("Run " + msg);
}
function feedback(msg,elem) {
	var orange = document.getElementById(elem);	
	if (msg == "Time=Money") msg = "TimeEqualsMoney";
	if (msg == "PrefCommander") msg = "PreferenceCommander";
	lastApp = msg;
	orange.style.display="none";
	feedbackcore(msg,elem);
}

function feedbackLast(elem) {
	feedback(lastApp,elem);
}

function visitfeedback(msg) {
	debug("Visit " + msg);
}

function showCover(guy) {
	var dude = document.getElementById(guy);
	dude.style.display="block";
}

function hideCover(guy) {
	var dude = document.getElementById(guy);
	dude.style.display="none";
}

function coverClicked(guy) {
   if (guy == "ruler")
   clicked("Philosophy/");
  else if (guy == "eraser")
    clicked ("Stone_Design.html");
   else 
   clicked("CreateArt/");
}

function visitfeedbackguy(msg, guy) {
	var dude = document.getElementById(guy);
	dude.style.display="block";
	debug("Visit " + msg);
}
function clearfeedbackguy(guy) {
	var dude = document.getElementById(guy);
	debug.box.style.display="none";
	debug2.box.style.display="none";
	dude.style.display="none";
}


function linkfeedback(msg,guy) {
	var dude = document.getElementById(guy);
	dude.style.display="block";
	debug2(msg);
}

function clearfeedback() {
	var dude = document.getElementById("orange");
	dude.style.display="none";
	debug.box.style.display="none";
}

function clearfeedback2(guy) {
	var dude = document.getElementById(guy);
	dude.style.display="none";
	debug2.box.style.display="none";
	debug.box.style.display="none";
}

function stoneOver(event) {
	event.target.src = "iMaj-b.png";
	debug2("Open iMaginator");
}

function stoneOut(event) {
	event.target.src = "iMaj-g.png";
	debug2.box.style.display="none";
}

function stoneUp(event) {
	stoneOut(event);
	openApp('iMaginator');
}
