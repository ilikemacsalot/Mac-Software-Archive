//
//  NSApplication+AppCopies.h
//  Sparkle
//
//  Created by Andy Matuschak on 3/16/06.
//  Copyright 2006 Andy Matuschak. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSApplication (SUAppCopies)
- (int)copiesRunning;
@end
